<?php echo $template_message; ?>.
<?php /**PATH C:\xampp\htdocs\harminder\example-app\resources\views/mail/subscription.blade.php ENDPATH**/ ?>