
<?php $__env->startPush('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/files/assets/sweetalert.min.js')); ?>"></script>

  <script>
              function userstatus(id){
        event.preventDefault();
        swal({
            title: "Are you sure you want to delete this record?",
            text: "If you delete this, it will be gone forever.",
            icon: "warning",
            type: "warning",
            buttons: ["Cancel","Yes!"],
            confirmButtonColor: '#67355c',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((willDelete) => {
            if (willDelete) {
               $.ajax({
    url: "<?php echo e(route('user.fb_account_delete')); ?>",
    method: "POST",
    data:{
        _token: '<?php echo e(csrf_token()); ?>',
        id: id
    },
    success:function(response){
        if(response == 1)
        {
                        new PNotify({title: 'Success',text: "User Active Successfully",
                        icon: 'icofont icofont-info-circle',type: 'success'
                    });
                        location.reload();
        }
        else
        {
           new PNotify({title: 'Danger',text: "Something Error",
                        icon: 'icofont icofont-info-circle',type: 'error'
                        });
        }
    },
    error: function (xhr, ajaxOptions, thrownError) {
        console.log(xhr.status);
        console.log(thrownError);
    }
})
            }
        });
              }

      </script>
<?php $__env->stopPush(); ?>
      <?php $__env->startSection('content'); ?>
<div class="pcoded-content"> 
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">   
<div class="page-header">
  <div class="row align-items-end">
    <div class="col-lg-8">
      <div class="page-header-title">
        <div class="d-inline">
          <h4>Edit User</h4>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>           
<div class="page-body">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-block">
          <h4 class="sub-title">User Details</h4>
        <div class="col-lg-12 col-xl-12">

  <ul class="nav nav-tabs md-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#home3" role="tab" aria-selected="false">Profile</a>
      <div class="slide"></div>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#profile3" role="tab" aria-selected="false">Facebook Accounts</a>
      <div class="slide"></div>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#messages3" role="tab" aria-selected="true">Subscription</a>
      <div class="slide"></div>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#settings3" role="tab" aria-selected="false">Usages</a>
      <div class="slide"></div>
    </li>
  </ul>
  <div class="tab-content card-block">
    <div class="tab-pane active" id="home3" role="tabpanel">
      <form method="post" class="col-md-8" action="<?php echo e(route('user.user_edit_submit', ['id' => $userdetail->id])); ?>">
            <?php echo csrf_field(); ?>
             <div class="form-group row">
              <label class="col-sm-4 col-form-label">Name: *</label>
              <div class="col-sm-8">
                <input type="text" value="<?php echo e($userdetail->name); ?>" name="name" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-4 col-form-label">Email: *</label>
              <div class="col-sm-8">
                <input type="email" value="<?php echo e($userdetail->email); ?>" name="email" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-4 col-form-label">Licence: *</label>
              <div class="col-sm-8">
                <input type="text" value="<?php echo e($userdetail->license_key); ?>" name="license" class="form-control">
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-4 col-form-label">No of allow FB accounts: *</label>
              <div class="col-sm-8">
                <input type="number" value="<?php echo e($userdetail->fb_accounts); ?>" name="fb_accounts" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-4 col-form-label"></label>
              <div class="col-sm-4">
                <button type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20">Update</button>
              </div>
            </div>
            
          </form>
    </div>
    <div class="tab-pane" id="profile3" role="tabpanel">
      <table class="table table-border">

        <thead>
          <tr>
            <th>Sno.</th>
            <th>Name</th>
            <th>Primary Account</th>
            <th>Action</th>
          </tr>
        </thead>
      <tbody>
        <?php
        $s = 0;
        ?>
        <?php $__currentLoopData = $userdetail->account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $useraccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $s++;
      ?>

      <tr>
          <td><?php echo e($s); ?></td>
          <td><?php echo e($useraccount->fb_account_id); ?></td>
            <td>
              <?php if($useraccount->is_primary == 1): ?>
              <i class="icofont icofont-ui-check"></i> 
              <?php else: ?>
              <i class="icofont icofont-ui-close"></i>
              <?php endif; ?>
            </td>
            <td><a class="btn btn-danger" onclick="userstatus(<?php echo e($useraccount->id); ?>)" href="#"><i class="icofont icofont-ui-delete"></i></a></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
    </div>
    <div class="tab-pane" id="messages3" role="tabpanel">
      <div class="form-group row">

              <label class="col-sm-2 col-form-label">Name: *</label>
              <div class="col-sm-8">
                <label class="col-sm-12 col-form-label">  <?php echo e($userdetail->plan->name); ?></label>

            </div>
          </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Email: *</label>
              <div class="col-sm-8">
                <label class="col-sm-12 col-form-label">  <?php echo e($userdetail->started_on); ?></label>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Licence: *</label>
              <div class="col-sm-8">
                 <label class="col-sm-12 col-form-label">  <?php echo e($userdetail->expired_on); ?></label>
              </div>
            </div>
    </div>
    <div class="tab-pane" id="settings3" role="tabpanel">
      <table class="table table-border">

        <thead>
          <tr>
            <th>Feature Name</th>
            <th>Total</th>
          </tr>
        </thead>
      <tbody>
        <tr>
          <td>Tags</td><td><?php echo e($userdetail->tags_count); ?></td>
        </tr> 
        <tr>
          <td>Note Created</td><td> <?php echo e($userdetail->note_count); ?> </td>
        </tr>
       <tr>
          <td>Message templates</td><td> <?php echo e($userdetail->template_count); ?></td>
        </tr> 
        <tr>
          <td>Message Created</td><td> <?php echo e($userdetail->message); ?></td>
        </tr>
        <tr>
          <td>Message reminders</td><td><?php echo e($userdetail->reminder_count); ?> </td>
        </tr>     
      </tbody>
      </table>
    </div>
  </div>
</div>
        </div>
      </div>
        </div>
      </div>
    </div>
</div>
</div>
</div>
</div>
</div>
 <?php $__env->stopSection(); ?>
           
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/api.chatsilo.com/resources/views/admin/user/user_detail.blade.php ENDPATH**/ ?>