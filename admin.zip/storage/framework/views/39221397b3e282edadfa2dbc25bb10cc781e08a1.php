
<?php $__env->startPush('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/files/assets/sweetalert.min.js')); ?>"></script>

  <script>
              function userstatus(id){
        event.preventDefault();
        swal({
            title: "Are you sure you want to delete this record?",
            text: "If you delete this, it will be gone forever.",
            icon: "warning",
            type: "warning",
            buttons: ["Cancel","Yes!"],
            confirmButtonColor: '#67355c',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((willDelete) => {
            if (willDelete) {
               $.ajax({
    url: "<?php echo e(route('user.fb_account_delete')); ?>",
    method: "POST",
    data:{
        _token: '<?php echo e(csrf_token()); ?>',
        id: id
    },
    success:function(response){
        if(response == 1)
        {
                        new PNotify({title: 'Success',text: "User Active Successfully",
                        icon: 'icofont icofont-info-circle',type: 'success'
                    });
                        location.reload();
        }
        else
        {
           new PNotify({title: 'Danger',text: "Something Error",
                        icon: 'icofont icofont-info-circle',type: 'error'
                        });
        }
    },
    error: function (xhr, ajaxOptions, thrownError) {
        console.log(xhr.status);
        console.log(thrownError);
    }
})
            }
        });
              }

      </script>
<?php $__env->stopPush(); ?>
      <?php $__env->startSection('content'); ?>
<div class="pcoded-content"> 
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">   
<div class="page-header">
  <div class="row align-items-end">
    <div class="col-lg-8">
      <div class="page-header-title">
        <div class="d-inline">
          <h4>Plan</h4>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>           
<div class="page-body">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-block">
          <h4 class="sub-title">Plan Add</h4>
        <div class="col-lg-12 col-xl-12">
      <form method="post" class="col-md-8" action="<?php echo e(route('staff.plan.plan_add_submit')); ?>">
            <?php echo csrf_field(); ?>
             <div class="form-group row">
              <label class="col-sm-4 col-form-label">Name: *</label>
              <div class="col-sm-8">
                <input type="text"  name="name" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-4 col-form-label">Price: *</label>
              <div class="col-sm-8">
                <input type="text"  name="price" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-4 col-form-label">Description: *</label>
              <div class="col-sm-8">
                <textarea type="text"  name="description" class="form-control"></textarea>
              </div>
            </div>

            <div class="form-group row">
              <label class="col-sm-4 col-form-label"></label>
              <div class="col-sm-4">
                <button type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20">Submit</button>
              </div>
            </div>
            
          </form>
        </div>
      </div>
        </div>
      </div>
    </div>
</div>
</div>
</div>
</div>
</div>
 <?php $__env->stopSection(); ?>
           
<?php echo $__env->make('staff.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kamilkozar/public_html/admin/resources/views/staff/plan/add.blade.php ENDPATH**/ ?>